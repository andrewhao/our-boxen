# Tig Puppet Module for Boxen

## Usage

```puppet
include tig
```

## Required Puppet Modules

* boxen
* homebrew
* stdlib
